package eshop.homedecor.shopapi.enums;


public interface CodeEnum {
    Integer getCode();

}
